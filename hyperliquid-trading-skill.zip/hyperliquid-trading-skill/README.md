# Hyperliquid Trading Skill for OpenClaw

Trade perpetuals & spot, manage positions, check balances, and move funds on Hyperliquid — all through natural conversation via Telegram (text or voice).

## Features

| Category | Commands |
|----------|----------|
| **Info** | Balance, positions, open orders, price, funding rate, orderbook, fill history |
| **Perp Trading** | Market buy/sell, limit orders, close positions, cancel orders, TP/SL, leverage |
| **Spot Trading** | Buy/sell spot tokens |
| **Funding** | Spot↔perp transfers, send USDC, withdraw to Arbitrum |
| **Safety** | Confirmation required for trades/transfers, order size limits, asset allowlists |

## Quick Start

```bash
# 1. Clone/download this skill
# 2. Run installer
chmod +x install.sh && ./install.sh

# 3. Configure your API wallet
nano ~/.openclaw/workspace/skills/hyperliquid-trading/config.json

# 4. Restart OpenClaw
openclaw gateway restart

# 5. Test in Telegram
# "Show my HL balance"
# "Buy 0.1 ETH"
# "Close my BTC short"
```

## Configuration

### Get an API Wallet (Recommended)

1. Go to https://app.hyperliquid.xyz/API
2. Click "Create API Wallet"
3. Name it (e.g., "clawdbot")
4. Copy the private key
5. The API wallet can trade but **cannot withdraw** — your funds stay safe

### config.json

```json
{
  "account_address": "0xYOUR_MAIN_WALLET",
  "secret_key": "0xAPI_WALLET_PRIVATE_KEY",
  "testnet": false,
  "vault_address": null,
  "default_slippage": 0.03,
  "confirm_trades": true,
  "confirm_transfers": true,
  "max_single_order_usd": 10000,
  "allowed_assets": []
}
```

| Field | Description |
|-------|-------------|
| `account_address` | Your main Hyperliquid wallet (0x...) |
| `secret_key` | API wallet private key (NOT your main key!) |
| `testnet` | `true` for testnet, `false` for mainnet |
| `vault_address` | Optional vault address if trading via vault |
| `default_slippage` | Max slippage for market orders (0.03 = 3%) |
| `confirm_trades` | Require "yes" before executing trades |
| `confirm_transfers` | Require "yes" before transfers |
| `max_single_order_usd` | Safety cap per order in USD |
| `allowed_assets` | `[]` = all; `["BTC","ETH"]` = restrict |

### Environment Variables (override config.json)

```
HL_ACCOUNT_ADDRESS=0x...
HL_SECRET_KEY=0x...
HL_TESTNET=false
HL_VAULT_ADDRESS=0x...
```

## Example Conversations

```
You: "What's my balance on Hyperliquid?"
Bot: 💰 Hyperliquid Balance
     ├─ Equity: $12,450.32
     ├─ Available: $8,200.15
     └─ Unrealized PnL: +$312.50

You: "Long 0.5 ETH"
Bot: 📊 Order Preview:
       Market Buy ETH 0.5 @ ~$3,520
       Est. Value: ~$1,760 | Slippage: 3%
     ⚠️ Confirm?

You: "Yes"
Bot: ✅ Filled: Buy 0.5 ETH @ $3,521.40

You: "Set stop loss at 3200 and take profit at 4000"
Bot: TP/SL set for ETH:
     📈 Take Profit: $4,000
     🛑 Stop Loss: $3,200

You: "Move 500 to spot"
Bot: Transfer 500 USDC: perp → spot. Confirm?

You: "Show my positions"
Bot: 📈 Open Positions (1)
     ETH-PERP: Long 0.5 @ $3,521
     PnL: +$15.30 (+0.87%) | Liq: $2,890
```

## File Structure

```
hyperliquid-trading/
├── SKILL.md              # Skill definition (intent detection + routing)
├── README.md             # This file
├── config.example.json   # Template config
├── install.sh            # One-command installer
└── scripts/
    ├── hl_config.py      # Shared config loader & utilities
    ├── hl_info.py        # Read-only: balance, positions, prices
    ├── hl_trade.py       # Trading: market/limit orders, close, TP/SL
    └── hl_transfer.py    # Funding: spot↔perp, send, withdraw
```

## Security Notes

- **Always use an API wallet**, never your main wallet private key
- API wallets can trade but cannot withdraw funds
- `max_single_order_usd` prevents fat-finger errors
- `confirm_trades` ensures you approve before execution
- `allowed_assets` restricts which assets the bot can trade
- Config file permissions: `chmod 600 config.json`

## Dependencies

- Python 3.9+
- `hyperliquid-python-sdk` >= 0.22.0
- `eth-account` >= 0.13.0
