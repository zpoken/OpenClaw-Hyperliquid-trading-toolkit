---
name: hyperliquid-trading
description: >
  Access, fund, and trade on Hyperliquid DEX via conversational commands.
  Supports perp and spot trading, position management, balance checks,
  deposits/withdrawals, and internal transfers. Works with voice and text.
metadata:
  openclaw:
    requires:
      bins:
        - python3
      pip:
        - hyperliquid-python-sdk>=0.22.0
        - eth-account>=0.13.0
      env:
        - HL_ACCOUNT_ADDRESS
        - HL_SECRET_KEY
      optional_env:
        - HL_TESTNET       # "true" to use testnet (default: mainnet)
        - HL_VAULT_ADDRESS  # if trading via a vault
---

# Hyperliquid Trading Skill

Trade perpetuals and spot, manage positions, check balances, and move funds on Hyperliquid — all through natural conversation.

## When to activate

### INFO commands — activate when user asks about:
- Account balances: "what's my HL balance", "show my Hyperliquid balance", "how much USDC do I have"
- Positions: "show my positions", "what am I holding on HL", "my perp positions", "am I in any trades"
- Open orders: "show my open orders", "any pending orders", "list my orders"
- PnL: "what's my PnL", "how are my trades doing", "unrealized profit"
- Market data: "what's BTC price on HL", "ETH funding rate", "show orderbook for SOL"
- Trade history: "show my recent fills", "last trades", "fill history"

### TRADE commands — activate when user wants to:
- Open positions: "buy 0.1 ETH", "short 1 BTC at 100k", "long SOL market", "open a 5x BTC long"
- Close positions: "close my ETH position", "close all", "exit BTC short"
- Place limit orders: "buy 0.5 ETH at 3500", "sell 1 SOL at 200"
- Set TP/SL: "set stop loss on BTC at 95k", "take profit at 110k"
- Cancel orders: "cancel my ETH orders", "cancel all orders"
- Modify leverage: "set BTC leverage to 10x", "change SOL leverage to 5x cross"
- Spot trades: "buy 100 PURR spot", "sell my HYPE tokens"

### FUND / TRANSFER commands — activate when user wants to:
- Check balances: "how much can I withdraw", "spot wallet balance"
- Internal transfer: "move 500 USDC to spot", "transfer from spot to perp"
- Send USDC: "send 100 USDC to 0xabc..."
- Withdraw: "withdraw 1000 USDC to Arbitrum"
- Deposit info: "how do I deposit to HL", "bridge funds to Hyperliquid"

### Language patterns (EN + RU):
- English: "buy", "sell", "long", "short", "close", "balance", "position", "order", "HL", "Hyperliquid", "withdraw", "deposit", "transfer", "funding", "PnL"
- Russian: "купи", "продай", "лонг", "шорт", "закрой", "баланс", "позиция", "ордер", "вывод", "депозит", "перевод", "фандинг"

### Do NOT activate for:
- General crypto discussion without action intent
- Questions about Hyperliquid the company/token that aren't about the user's account
- Requests to use other exchanges (Binance, Bybit, etc.)

---

## Configuration

The skill requires a config file at:
```
~/.openclaw/workspace/skills/hyperliquid-trading/config.json
```

```json
{
  "account_address": "0xYOUR_MAIN_WALLET_ADDRESS",
  "secret_key": "0xYOUR_API_WALLET_PRIVATE_KEY",
  "testnet": false,
  "vault_address": null,
  "default_slippage": 0.03,
  "confirm_trades": true,
  "confirm_transfers": true,
  "max_single_order_usd": 10000,
  "allowed_assets": []
}
```

**Security notes:**
- Use an **API wallet** (generated at https://app.hyperliquid.xyz/API), NOT your main wallet private key
- API wallets can trade but CANNOT withdraw — this protects your funds
- `allowed_assets` empty = all assets allowed; set `["BTC", "ETH"]` to restrict
- `max_single_order_usd` is a safety cap per single order

Environment variables override config file values:
- `HL_ACCOUNT_ADDRESS` → `account_address`
- `HL_SECRET_KEY` → `secret_key`
- `HL_TESTNET` → `testnet`
- `HL_VAULT_ADDRESS` → `vault_address`

---

## How to process commands

### Step 1: Parse intent

Classify the user's message into one of these command types:

| Category | Command | Script & Args |
|----------|---------|---------------|
| **INFO** | balance | `hl_info.py balance` |
| **INFO** | positions | `hl_info.py positions` |
| **INFO** | open_orders | `hl_info.py open_orders` |
| **INFO** | price `<coin>` | `hl_info.py price <COIN>` |
| **INFO** | funding `<coin>` | `hl_info.py funding <COIN>` |
| **INFO** | orderbook `<coin>` | `hl_info.py orderbook <COIN>` |
| **INFO** | fills | `hl_info.py fills` |
| **TRADE** | market_buy | `hl_trade.py market_buy <COIN> <SIZE>` |
| **TRADE** | market_sell | `hl_trade.py market_sell <COIN> <SIZE>` |
| **TRADE** | limit_buy | `hl_trade.py limit_buy <COIN> <SIZE> <PRICE>` |
| **TRADE** | limit_sell | `hl_trade.py limit_sell <COIN> <SIZE> <PRICE>` |
| **TRADE** | close | `hl_trade.py close <COIN>` |
| **TRADE** | close_all | `hl_trade.py close_all` |
| **TRADE** | cancel | `hl_trade.py cancel <COIN>` |
| **TRADE** | cancel_all | `hl_trade.py cancel_all` |
| **TRADE** | set_leverage | `hl_trade.py set_leverage <COIN> <LEVERAGE> [cross\|isolated]` |
| **TRADE** | tpsl | `hl_trade.py tpsl <COIN> <TP_PRICE> <SL_PRICE>` |
| **TRADE** | spot_buy | `hl_trade.py spot_buy <TOKEN> <SIZE>` |
| **TRADE** | spot_sell | `hl_trade.py spot_sell <TOKEN> <SIZE>` |
| **FUND** | transfer_to_spot | `hl_transfer.py to_spot <AMOUNT>` |
| **FUND** | transfer_to_perp | `hl_transfer.py to_perp <AMOUNT>` |
| **FUND** | send_usd | `hl_transfer.py send_usd <ADDRESS> <AMOUNT>` |
| **FUND** | withdraw | `hl_transfer.py withdraw <AMOUNT>` |
| **FUND** | deposit_info | (no script — just provide instructions) |

### Step 2: Confirm destructive actions

For TRADE and FUND commands (when `confirm_trades` / `confirm_transfers` is true), present a summary and ask for confirmation BEFORE executing:

```
📊 Order Preview:
  Action: Market Buy
  Asset: ETH-PERP
  Size: 0.5 ETH
  Est. Price: ~$3,520
  Est. Value: ~$1,760
  Slippage: 3%

⚠️ Confirm? (yes/no)
```

Only execute after receiving explicit "yes", "да", "confirm", "go", or "do it".

### Step 3: Execute

Run the appropriate script:
```bash
python3 ~/.openclaw/workspace/skills/hyperliquid-trading/scripts/<script>.py <args>
```

### Step 4: Report result

Format the output cleanly. Examples:

**Balance:**
```
💰 Hyperliquid Balance
├─ Equity: $12,450.32
├─ Available: $8,200.15
├─ Margin Used: $4,250.17
└─ Unrealized PnL: +$312.50
```

**Positions:**
```
📈 Open Positions (2)
┌─ ETH-PERP: Long 2.5 @ $3,480
│  PnL: +$125.00 (+1.44%)  |  Liq: $2,890
│  Leverage: 5x cross
├─ BTC-PERP: Short 0.1 @ $101,200
│  PnL: -$45.00 (-0.44%)  |  Liq: $115,800
│  Leverage: 3x cross
```

**Trade executed:**
```
✅ Order Filled
  Market Buy 0.5 ETH @ $3,521.40
  Total: $1,760.70
  Status: filled
```

---

## Deposit instructions (no script needed)

When user asks how to deposit:

> To fund your Hyperliquid account:
> 1. Go to https://app.hyperliquid.xyz
> 2. Click "Deposit" in the top right
> 3. Send USDC on Arbitrum to the bridge address shown
> 4. Funds arrive in ~1 minute
>
> You can also bridge from other chains via the Hyperliquid bridge.
> Minimum deposit: $1 USDC

---

## Error handling

| Error | Response |
|-------|----------|
| `Insufficient margin` | "Not enough margin. Available: $X. Need: ~$Y. Deposit more USDC or reduce position size." |
| `Asset not found` | "I couldn't find that asset on Hyperliquid. Did you mean [closest match]?" |
| `Rate limited` | "Hyperliquid rate limit hit. Trying again in 5 seconds..." (auto-retry once) |
| `Connection error` | "Can't reach Hyperliquid API right now. I'll retry in a moment." |
| Config missing | "Hyperliquid isn't configured yet. Set your API wallet key — see setup instructions." |
| Order too large | "This order ($X) exceeds your safety limit ($Y). Adjust max_single_order_usd in config if intended." |
| Disallowed asset | "Trading [COIN] is not in your allowed assets list. Update config to add it." |

---

## Setup instructions (show when config is missing)

```
🔧 Hyperliquid Setup

1. Generate an API wallet at https://app.hyperliquid.xyz/API
   - Name it (e.g., "clawdbot")
   - Copy the private key

2. Create config:
   mkdir -p ~/.openclaw/workspace/skills/hyperliquid-trading
   nano ~/.openclaw/workspace/skills/hyperliquid-trading/config.json

3. Paste:
   {
     "account_address": "0xYOUR_MAIN_WALLET",
     "secret_key": "0xAPI_WALLET_PRIVATE_KEY",
     "testnet": false
   }

4. Install dependencies:
   pip install hyperliquid-python-sdk eth-account

5. Restart OpenClaw and test:
   "Show my HL balance"
```
