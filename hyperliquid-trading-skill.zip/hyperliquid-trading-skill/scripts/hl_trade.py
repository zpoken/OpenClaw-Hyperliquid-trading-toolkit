#!/usr/bin/env python3
"""
Hyperliquid Trade Commands
Execute trades: market/limit orders, close positions, cancel orders, set leverage, TP/SL.

Usage:
  python3 hl_trade.py market_buy <COIN> <SIZE>
  python3 hl_trade.py market_sell <COIN> <SIZE>
  python3 hl_trade.py limit_buy <COIN> <SIZE> <PRICE>
  python3 hl_trade.py limit_sell <COIN> <SIZE> <PRICE>
  python3 hl_trade.py close <COIN>
  python3 hl_trade.py close_all
  python3 hl_trade.py cancel <COIN>
  python3 hl_trade.py cancel_all
  python3 hl_trade.py set_leverage <COIN> <LEVERAGE> [cross|isolated]
  python3 hl_trade.py tpsl <COIN> <TP_PRICE> <SL_PRICE>
  python3 hl_trade.py spot_buy <TOKEN> <SIZE>
  python3 hl_trade.py spot_sell <TOKEN> <SIZE>

All commands output JSON. Trade commands include a "preview" mode when called with --preview flag.
"""

import sys
import json
import traceback

from hl_config import (
    load_config, validate_config, setup_exchange, check_asset_allowed,
    format_usd, output_json
)


def get_mid_price(info, coin: str) -> float:
    """Get current mid price for an asset."""
    mids = info.all_mids()
    price = mids.get(coin.upper())
    if price is None:
        for key, val in mids.items():
            if key.upper().startswith(coin.upper()):
                return float(val)
        raise ValueError(f"Asset {coin} not found")
    return float(price)


def check_order_size(config: dict, coin: str, size: float, price: float):
    """Validate order size against safety limits."""
    usd_value = size * price
    max_val = config.get("max_single_order_usd", 10000)
    if usd_value > max_val:
        raise ValueError(
            f"Order value ${usd_value:,.2f} exceeds safety limit ${max_val:,.2f}. "
            f"Update max_single_order_usd in config to increase."
        )


def cmd_market_buy(exchange, info, config, coin: str, size: float, preview: bool = False):
    """Place a market buy order (perps)."""
    coin = coin.upper()
    if not check_asset_allowed(config, coin):
        output_json({"error": "disallowed_asset", "coin": coin})
        return

    mid = get_mid_price(info, coin)
    slippage = config.get("default_slippage", 0.03)
    est_price = mid * (1 + slippage)
    check_order_size(config, coin, size, est_price)

    if preview:
        output_json({
            "command": "market_buy",
            "preview": True,
            "coin": coin,
            "size": size,
            "est_price": round(est_price, 2),
            "est_value": round(size * est_price, 2),
            "slippage": f"{slippage*100:.1f}%",
            "mid_price": mid,
        })
        return

    result = exchange.market_open(coin, True, size, slippage, cloid=None)
    status = result.get("status", "unknown")
    response = result.get("response", {})

    if status == "ok":
        data = response.get("data", {})
        statuses = data.get("statuses", [{}])
        fill_info = statuses[0] if statuses else {}
        filled = fill_info.get("filled", {})
        output_json({
            "command": "market_buy",
            "status": "filled",
            "coin": coin,
            "size": size,
            "avg_price": float(filled.get("avgPx", mid)),
            "total_sz": float(filled.get("totalSz", size)),
            "oid": filled.get("oid"),
        })
    else:
        output_json({
            "command": "market_buy",
            "status": "error",
            "coin": coin,
            "raw_response": result,
        })


def cmd_market_sell(exchange, info, config, coin: str, size: float, preview: bool = False):
    """Place a market sell order (perps)."""
    coin = coin.upper()
    if not check_asset_allowed(config, coin):
        output_json({"error": "disallowed_asset", "coin": coin})
        return

    mid = get_mid_price(info, coin)
    slippage = config.get("default_slippage", 0.03)
    est_price = mid * (1 - slippage)
    check_order_size(config, coin, size, est_price)

    if preview:
        output_json({
            "command": "market_sell",
            "preview": True,
            "coin": coin,
            "size": size,
            "est_price": round(est_price, 2),
            "est_value": round(size * est_price, 2),
            "slippage": f"{slippage*100:.1f}%",
            "mid_price": mid,
        })
        return

    result = exchange.market_open(coin, False, size, slippage, cloid=None)
    status = result.get("status", "unknown")
    response = result.get("response", {})

    if status == "ok":
        data = response.get("data", {})
        statuses = data.get("statuses", [{}])
        fill_info = statuses[0] if statuses else {}
        filled = fill_info.get("filled", {})
        output_json({
            "command": "market_sell",
            "status": "filled",
            "coin": coin,
            "size": size,
            "avg_price": float(filled.get("avgPx", mid)),
            "total_sz": float(filled.get("totalSz", size)),
        })
    else:
        output_json({
            "command": "market_sell",
            "status": "error",
            "raw_response": result,
        })


def cmd_limit_buy(exchange, info, config, coin: str, size: float, price: float, preview: bool = False):
    """Place a limit buy order."""
    coin = coin.upper()
    if not check_asset_allowed(config, coin):
        output_json({"error": "disallowed_asset", "coin": coin})
        return

    check_order_size(config, coin, size, price)

    if preview:
        mid = get_mid_price(info, coin)
        output_json({
            "command": "limit_buy",
            "preview": True,
            "coin": coin,
            "size": size,
            "limit_price": price,
            "est_value": round(size * price, 2),
            "mid_price": mid,
            "distance_from_mid": f"{((mid - price) / mid * 100):.2f}%",
        })
        return

    result = exchange.order(
        coin, True, size, price,
        order_type={"limit": {"tif": "Gtc"}},
        reduce_only=False,
    )
    status = result.get("status", "unknown")

    if status == "ok":
        data = result.get("response", {}).get("data", {})
        statuses = data.get("statuses", [{}])
        output_json({
            "command": "limit_buy",
            "status": "placed",
            "coin": coin,
            "size": size,
            "price": price,
            "order_status": statuses[0] if statuses else {},
        })
    else:
        output_json({"command": "limit_buy", "status": "error", "raw_response": result})


def cmd_limit_sell(exchange, info, config, coin: str, size: float, price: float, preview: bool = False):
    """Place a limit sell order."""
    coin = coin.upper()
    if not check_asset_allowed(config, coin):
        output_json({"error": "disallowed_asset", "coin": coin})
        return

    check_order_size(config, coin, size, price)

    if preview:
        mid = get_mid_price(info, coin)
        output_json({
            "command": "limit_sell",
            "preview": True,
            "coin": coin,
            "size": size,
            "limit_price": price,
            "est_value": round(size * price, 2),
            "mid_price": mid,
            "distance_from_mid": f"{((price - mid) / mid * 100):.2f}%",
        })
        return

    result = exchange.order(
        coin, False, size, price,
        order_type={"limit": {"tif": "Gtc"}},
        reduce_only=False,
    )
    status = result.get("status", "unknown")

    if status == "ok":
        data = result.get("response", {}).get("data", {})
        statuses = data.get("statuses", [{}])
        output_json({
            "command": "limit_sell",
            "status": "placed",
            "coin": coin,
            "size": size,
            "price": price,
            "order_status": statuses[0] if statuses else {},
        })
    else:
        output_json({"command": "limit_sell", "status": "error", "raw_response": result})


def cmd_close(exchange, info, config, coin: str, preview: bool = False):
    """Close an open position for a specific coin."""
    coin = coin.upper()
    address = config["account_address"]
    state = info.user_state(address)

    # Find position
    position = None
    for pos_data in state.get("assetPositions", []):
        pos = pos_data.get("position", {})
        if pos.get("coin", "").upper() == coin:
            szi = float(pos.get("szi", 0))
            if szi != 0:
                position = pos
                break

    if not position:
        output_json({"command": "close", "error": "no_position", "coin": coin,
                      "message": f"No open position found for {coin}"})
        return

    szi = float(position["szi"])
    entry_px = float(position.get("entryPx", 0))
    mid = get_mid_price(info, coin)
    unrealized_pnl = float(position.get("unrealizedPnl", 0))

    if preview:
        output_json({
            "command": "close",
            "preview": True,
            "coin": coin,
            "side": "Long" if szi > 0 else "Short",
            "size": abs(szi),
            "entry_price": entry_px,
            "current_price": mid,
            "est_pnl": unrealized_pnl,
        })
        return

    slippage = config.get("default_slippage", 0.03)
    is_buy = szi < 0  # If short, we buy to close
    result = exchange.market_close(coin, abs(szi), slippage, cloid=None)
    status = result.get("status", "unknown")

    if status == "ok":
        output_json({
            "command": "close",
            "status": "closed",
            "coin": coin,
            "closed_size": abs(szi),
            "entry_price": entry_px,
            "close_price": mid,
            "est_pnl": unrealized_pnl,
        })
    else:
        output_json({"command": "close", "status": "error", "raw_response": result})


def cmd_close_all(exchange, info, config, preview: bool = False):
    """Close all open positions."""
    address = config["account_address"]
    state = info.user_state(address)
    slippage = config.get("default_slippage", 0.03)

    positions = []
    for pos_data in state.get("assetPositions", []):
        pos = pos_data.get("position", {})
        szi = float(pos.get("szi", 0))
        if szi != 0:
            positions.append({
                "coin": pos["coin"],
                "szi": szi,
                "entry_px": float(pos.get("entryPx", 0)),
                "unrealized_pnl": float(pos.get("unrealizedPnl", 0)),
            })

    if not positions:
        output_json({"command": "close_all", "message": "No open positions to close"})
        return

    if preview:
        output_json({
            "command": "close_all",
            "preview": True,
            "positions_to_close": len(positions),
            "positions": positions,
            "total_unrealized_pnl": sum(p["unrealized_pnl"] for p in positions),
        })
        return

    results = []
    for pos in positions:
        try:
            result = exchange.market_close(pos["coin"], abs(pos["szi"]), slippage)
            results.append({"coin": pos["coin"], "status": result.get("status", "unknown")})
        except Exception as e:
            results.append({"coin": pos["coin"], "status": "error", "message": str(e)})

    output_json({
        "command": "close_all",
        "status": "completed",
        "results": results,
    })


def cmd_cancel(exchange, info, config, coin: str):
    """Cancel all open orders for a specific coin."""
    coin = coin.upper()
    address = config["account_address"]
    orders = info.open_orders(address)

    # Filter orders for this coin
    coin_orders = [o for o in orders if o.get("coin", "").upper() == coin]

    if not coin_orders:
        output_json({"command": "cancel", "coin": coin, "message": "No open orders to cancel"})
        return

    result = exchange.cancel(coin, [o["oid"] for o in coin_orders])
    output_json({
        "command": "cancel",
        "coin": coin,
        "cancelled_count": len(coin_orders),
        "result": result,
    })


def cmd_cancel_all(exchange, info, config):
    """Cancel ALL open orders."""
    address = config["account_address"]
    orders = info.open_orders(address)

    if not orders:
        output_json({"command": "cancel_all", "message": "No open orders to cancel"})
        return

    # Group by coin
    by_coin = {}
    for o in orders:
        c = o.get("coin", "?")
        by_coin.setdefault(c, []).append(o["oid"])

    results = []
    for c, oids in by_coin.items():
        try:
            result = exchange.cancel(c, oids)
            results.append({"coin": c, "count": len(oids), "status": "cancelled"})
        except Exception as e:
            results.append({"coin": c, "count": len(oids), "status": "error", "message": str(e)})

    output_json({
        "command": "cancel_all",
        "total_cancelled": sum(r["count"] for r in results),
        "results": results,
    })


def cmd_set_leverage(exchange, info, config, coin: str, leverage: int, mode: str = "cross"):
    """Set leverage for a coin."""
    coin = coin.upper()
    is_cross = mode.lower() == "cross"

    result = exchange.update_leverage(leverage, coin, is_cross=is_cross)
    output_json({
        "command": "set_leverage",
        "coin": coin,
        "leverage": leverage,
        "mode": "cross" if is_cross else "isolated",
        "result": result,
    })


def cmd_tpsl(exchange, info, config, coin: str, tp_price: float, sl_price: float, preview: bool = False):
    """Set take-profit and stop-loss for an existing position."""
    coin = coin.upper()
    address = config["account_address"]
    state = info.user_state(address)

    # Find the position
    position = None
    for pos_data in state.get("assetPositions", []):
        pos = pos_data.get("position", {})
        if pos.get("coin", "").upper() == coin and float(pos.get("szi", 0)) != 0:
            position = pos
            break

    if not position:
        output_json({"command": "tpsl", "error": "no_position", "coin": coin})
        return

    szi = float(position["szi"])
    is_long = szi > 0
    size = abs(szi)

    if preview:
        mid = get_mid_price(info, coin)
        output_json({
            "command": "tpsl",
            "preview": True,
            "coin": coin,
            "side": "Long" if is_long else "Short",
            "size": size,
            "current_price": mid,
            "take_profit": tp_price,
            "stop_loss": sl_price,
        })
        return

    # Place TP order
    tp_result = exchange.order(
        coin,
        is_buy=not is_long,  # opposite side to close
        sz=size,
        limit_px=tp_price,
        order_type={"trigger": {"triggerPx": str(tp_price), "isMarket": True, "tpsl": "tp"}},
        reduce_only=True,
    )

    # Place SL order
    sl_result = exchange.order(
        coin,
        is_buy=not is_long,
        sz=size,
        limit_px=sl_price,
        order_type={"trigger": {"triggerPx": str(sl_price), "isMarket": True, "tpsl": "sl"}},
        reduce_only=True,
    )

    output_json({
        "command": "tpsl",
        "coin": coin,
        "take_profit": {"price": tp_price, "result": tp_result.get("status")},
        "stop_loss": {"price": sl_price, "result": sl_result.get("status")},
    })


def cmd_spot_buy(exchange, info, config, token: str, size: float, preview: bool = False):
    """Buy a spot token."""
    token = token.upper()
    # Spot pairs are formatted as TOKEN/USDC on Hyperliquid
    pair = f"{token}/USDC" if "/" not in token else token

    mid = get_mid_price(info, pair)
    slippage = config.get("default_slippage", 0.03)
    est_price = mid * (1 + slippage)

    if preview:
        output_json({
            "command": "spot_buy",
            "preview": True,
            "token": token,
            "pair": pair,
            "size": size,
            "est_price": round(est_price, 6),
            "est_value": round(size * est_price, 2),
        })
        return

    result = exchange.market_open(pair, True, size, slippage)
    output_json({
        "command": "spot_buy",
        "status": result.get("status", "unknown"),
        "token": token,
        "size": size,
        "raw_response": result,
    })


def cmd_spot_sell(exchange, info, config, token: str, size: float, preview: bool = False):
    """Sell a spot token."""
    token = token.upper()
    pair = f"{token}/USDC" if "/" not in token else token

    mid = get_mid_price(info, pair)
    slippage = config.get("default_slippage", 0.03)

    if preview:
        est_price = mid * (1 - slippage)
        output_json({
            "command": "spot_sell",
            "preview": True,
            "token": token,
            "pair": pair,
            "size": size,
            "est_price": round(est_price, 6),
            "est_value": round(size * est_price, 2),
        })
        return

    result = exchange.market_open(pair, False, size, slippage)
    output_json({
        "command": "spot_sell",
        "status": result.get("status", "unknown"),
        "token": token,
        "size": size,
        "raw_response": result,
    })


def main():
    if len(sys.argv) < 2:
        output_json({"error": "usage", "message": "Usage: hl_trade.py <command> [args] [--preview]"})
        sys.exit(1)

    config = load_config()
    if not validate_config(config):
        sys.exit(1)

    # Check for --preview flag
    preview = "--preview" in sys.argv
    args = [a for a in sys.argv if a != "--preview"]

    exchange, info = setup_exchange(config)
    command = args[1].lower()

    try:
        if command == "market_buy":
            cmd_market_buy(exchange, info, config, args[2], float(args[3]), preview)
        elif command == "market_sell":
            cmd_market_sell(exchange, info, config, args[2], float(args[3]), preview)
        elif command == "limit_buy":
            cmd_limit_buy(exchange, info, config, args[2], float(args[3]), float(args[4]), preview)
        elif command == "limit_sell":
            cmd_limit_sell(exchange, info, config, args[2], float(args[3]), float(args[4]), preview)
        elif command == "close":
            cmd_close(exchange, info, config, args[2], preview)
        elif command == "close_all":
            cmd_close_all(exchange, info, config, preview)
        elif command == "cancel":
            cmd_cancel(exchange, info, config, args[2])
        elif command == "cancel_all":
            cmd_cancel_all(exchange, info, config)
        elif command == "set_leverage":
            mode = args[4] if len(args) > 4 else "cross"
            cmd_set_leverage(exchange, info, config, args[2], int(args[3]), mode)
        elif command == "tpsl":
            cmd_tpsl(exchange, info, config, args[2], float(args[3]), float(args[4]), preview)
        elif command == "spot_buy":
            cmd_spot_buy(exchange, info, config, args[2], float(args[3]), preview)
        elif command == "spot_sell":
            cmd_spot_sell(exchange, info, config, args[2], float(args[3]), preview)
        else:
            output_json({"error": "unknown_command", "message": f"Unknown trade command: {command}"})
            sys.exit(1)

    except IndexError:
        output_json({"error": "missing_args", "message": f"Not enough arguments for '{command}'. Check usage."})
        sys.exit(1)
    except ValueError as e:
        output_json({"error": "value_error", "message": str(e)})
        sys.exit(1)
    except Exception as e:
        output_json({
            "error": "execution_error",
            "message": str(e),
            "traceback": traceback.format_exc(),
        })
        sys.exit(1)


if __name__ == "__main__":
    main()
