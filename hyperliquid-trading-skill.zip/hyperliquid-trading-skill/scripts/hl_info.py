#!/usr/bin/env python3
"""
Hyperliquid Info Commands
Read-only operations: balance, positions, orders, prices, funding, orderbook, fills.

Usage:
  python3 hl_info.py balance
  python3 hl_info.py positions
  python3 hl_info.py open_orders
  python3 hl_info.py price <COIN>
  python3 hl_info.py funding <COIN>
  python3 hl_info.py orderbook <COIN>
  python3 hl_info.py fills [limit]
"""

import sys
import json
import traceback

from hl_config import (
    load_config, validate_config, setup_info,
    format_usd, format_pnl, output_json
)


def cmd_balance(info, address: str):
    """Get account balance and margin summary."""
    state = info.user_state(address)
    spot_state = info.spot_user_state(address)

    # Perp account
    margin_summary = state.get("marginSummary", {})
    equity = float(margin_summary.get("accountValue", 0))
    total_margin = float(margin_summary.get("totalMarginUsed", 0))
    available = equity - total_margin

    # Cross margin
    cross = state.get("crossMarginSummary", {})

    # Withdrawable
    withdrawable = float(state.get("withdrawable", 0))

    # Spot balances
    spot_balances = []
    for bal in spot_state.get("balances", []):
        token = bal.get("coin", "?")
        hold = float(bal.get("hold", 0))
        total = float(bal.get("total", 0))
        if total > 0:
            spot_balances.append({
                "token": token,
                "total": total,
                "available": total - hold,
                "hold": hold,
            })

    output_json({
        "command": "balance",
        "perp": {
            "equity": equity,
            "available_margin": available,
            "margin_used": total_margin,
            "withdrawable": withdrawable,
        },
        "spot": spot_balances,
        "positions_count": len(state.get("assetPositions", [])),
    })


def cmd_positions(info, address: str):
    """Get all open perp positions."""
    state = info.user_state(address)
    positions = []

    for pos_data in state.get("assetPositions", []):
        pos = pos_data.get("position", {})
        coin = pos.get("coin", "?")
        szi = float(pos.get("szi", 0))
        if szi == 0:
            continue

        entry_px = float(pos.get("entryPx", 0))
        unrealized_pnl = float(pos.get("unrealizedPnl", 0))
        margin_used = float(pos.get("marginUsed", 0))
        liq_px = pos.get("liquidationPx")
        leverage = pos.get("leverage", {})

        position_value = abs(szi) * entry_px
        pnl_pct = (unrealized_pnl / position_value * 100) if position_value > 0 else 0

        positions.append({
            "coin": coin,
            "side": "Long" if szi > 0 else "Short",
            "size": abs(szi),
            "entry_price": entry_px,
            "unrealized_pnl": unrealized_pnl,
            "pnl_pct": round(pnl_pct, 2),
            "margin_used": margin_used,
            "liquidation_price": float(liq_px) if liq_px else None,
            "leverage": leverage,
        })

    output_json({
        "command": "positions",
        "count": len(positions),
        "positions": positions,
    })


def cmd_open_orders(info, address: str):
    """Get all open orders."""
    orders = info.open_orders(address)
    formatted = []
    for o in orders:
        formatted.append({
            "coin": o.get("coin", "?"),
            "side": "Buy" if o.get("side") == "B" else "Sell",
            "size": float(o.get("sz", 0)),
            "price": float(o.get("limitPx", 0)),
            "order_type": o.get("orderType", "?"),
            "oid": o.get("oid"),
            "timestamp": o.get("timestamp"),
        })

    output_json({
        "command": "open_orders",
        "count": len(formatted),
        "orders": formatted,
    })


def cmd_price(info, coin: str):
    """Get current mid price for an asset."""
    all_mids = info.all_mids()
    coin_upper = coin.upper()

    # Try exact match first, then partial
    price = all_mids.get(coin_upper)
    if price is None:
        # Try with common suffixes
        for key, val in all_mids.items():
            if key.upper().startswith(coin_upper):
                price = val
                coin_upper = key
                break

    if price is not None:
        output_json({
            "command": "price",
            "coin": coin_upper,
            "mid_price": float(price),
        })
    else:
        output_json({
            "command": "price",
            "error": "asset_not_found",
            "coin": coin,
            "message": f"Asset '{coin}' not found on Hyperliquid",
            "available_hint": "Use exact ticker symbols like BTC, ETH, SOL",
        })


def cmd_funding(info, coin: str):
    """Get current and predicted funding rate."""
    meta = info.meta()
    coin_upper = coin.upper()

    # Find asset index
    asset_idx = None
    asset_name = None
    for i, asset in enumerate(meta.get("universe", [])):
        if asset.get("name", "").upper() == coin_upper:
            asset_idx = i
            asset_name = asset["name"]
            break

    if asset_idx is None:
        output_json({
            "command": "funding",
            "error": "asset_not_found",
            "coin": coin,
        })
        return

    # Get funding info from contexts
    ctx = info.meta_and_asset_ctxs()
    asset_ctxs = ctx[1] if len(ctx) > 1 else []

    if asset_idx < len(asset_ctxs):
        actx = asset_ctxs[asset_idx]
        output_json({
            "command": "funding",
            "coin": asset_name,
            "funding_rate": float(actx.get("funding", 0)),
            "open_interest": float(actx.get("openInterest", 0)),
            "mark_price": float(actx.get("markPx", 0)),
            "oracle_price": float(actx.get("oraclePx", 0)),
            "premium": float(actx.get("premium", 0)),
        })
    else:
        output_json({"command": "funding", "coin": asset_name, "error": "no_context"})


def cmd_orderbook(info, coin: str):
    """Get L2 orderbook snapshot."""
    coin_upper = coin.upper()
    book = info.l2_snapshot(coin_upper)

    bids = [{"price": float(lvl["px"]), "size": float(lvl["sz"])} for lvl in book.get("levels", [[]])[0][:5]]
    asks = [{"price": float(lvl["px"]), "size": float(lvl["sz"])} for lvl in book.get("levels", [[], []])[1][:5]]

    output_json({
        "command": "orderbook",
        "coin": coin_upper,
        "bids": bids,
        "asks": asks,
    })


def cmd_fills(info, address: str, limit: int = 20):
    """Get recent fills / trade history."""
    fills = info.user_fills(address)
    recent = fills[:limit]

    formatted = []
    for f in recent:
        formatted.append({
            "coin": f.get("coin", "?"),
            "side": f.get("side", "?"),
            "size": float(f.get("sz", 0)),
            "price": float(f.get("px", 0)),
            "fee": float(f.get("fee", 0)),
            "time": f.get("time"),
            "closed_pnl": float(f.get("closedPnl", 0)),
        })

    output_json({
        "command": "fills",
        "count": len(formatted),
        "fills": formatted,
    })


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "usage", "message": "Usage: hl_info.py <command> [args]"}))
        sys.exit(1)

    config = load_config()
    if not validate_config(config):
        sys.exit(1)

    info = setup_info(config)
    address = config["account_address"]
    command = sys.argv[1].lower()

    try:
        if command == "balance":
            cmd_balance(info, address)
        elif command == "positions":
            cmd_positions(info, address)
        elif command == "open_orders":
            cmd_open_orders(info, address)
        elif command == "price":
            if len(sys.argv) < 3:
                output_json({"error": "missing_arg", "message": "Usage: hl_info.py price <COIN>"})
                sys.exit(1)
            cmd_price(info, sys.argv[2])
        elif command == "funding":
            if len(sys.argv) < 3:
                output_json({"error": "missing_arg", "message": "Usage: hl_info.py funding <COIN>"})
                sys.exit(1)
            cmd_funding(info, sys.argv[2])
        elif command == "orderbook":
            if len(sys.argv) < 3:
                output_json({"error": "missing_arg", "message": "Usage: hl_info.py orderbook <COIN>"})
                sys.exit(1)
            cmd_orderbook(info, sys.argv[2])
        elif command == "fills":
            limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
            cmd_fills(info, address, limit)
        else:
            output_json({"error": "unknown_command", "message": f"Unknown info command: {command}"})
            sys.exit(1)

    except Exception as e:
        output_json({
            "error": "execution_error",
            "message": str(e),
            "traceback": traceback.format_exc(),
        })
        sys.exit(1)


if __name__ == "__main__":
    main()
