"""
Shared configuration and setup utilities for Hyperliquid skill scripts.
Loads config from config.json or environment variables.
"""

import json
import os
import sys
from pathlib import Path

# Config file location
CONFIG_PATH = Path.home() / ".openclaw" / "workspace" / "skills" / "hyperliquid-trading" / "config.json"

# Fallback: look relative to script location
SCRIPT_DIR = Path(__file__).parent.parent
LOCAL_CONFIG_PATH = SCRIPT_DIR / "config.json"


def load_config() -> dict:
    """Load configuration from file and/or environment variables."""
    config = {
        "account_address": None,
        "secret_key": None,
        "testnet": False,
        "vault_address": None,
        "default_slippage": 0.03,
        "confirm_trades": True,
        "confirm_transfers": True,
        "max_single_order_usd": 10000,
        "allowed_assets": [],
    }

    # Try loading from config file
    for path in [CONFIG_PATH, LOCAL_CONFIG_PATH]:
        if path.exists():
            try:
                with open(path) as f:
                    file_config = json.load(f)
                config.update({k: v for k, v in file_config.items() if v is not None})
                break
            except (json.JSONDecodeError, IOError) as e:
                print(f"⚠️ Error reading config from {path}: {e}", file=sys.stderr)

    # Environment variables override file config
    env_map = {
        "HL_ACCOUNT_ADDRESS": "account_address",
        "HL_SECRET_KEY": "secret_key",
        "HL_TESTNET": "testnet",
        "HL_VAULT_ADDRESS": "vault_address",
    }
    for env_var, config_key in env_map.items():
        val = os.environ.get(env_var)
        if val:
            if config_key == "testnet":
                config[config_key] = val.lower() in ("true", "1", "yes")
            else:
                config[config_key] = val

    return config


def validate_config(config: dict) -> bool:
    """Validate that required config values are present."""
    if not config.get("account_address"):
        print(json.dumps({
            "error": "missing_config",
            "message": "HL_ACCOUNT_ADDRESS not set. Run setup first.",
            "setup_hint": "Generate an API wallet at https://app.hyperliquid.xyz/API"
        }))
        return False
    if not config.get("secret_key"):
        print(json.dumps({
            "error": "missing_config",
            "message": "HL_SECRET_KEY not set. Run setup first.",
            "setup_hint": "Set your API wallet private key in config.json"
        }))
        return False
    return True


def get_api_url(config: dict) -> str:
    """Get the appropriate API URL based on config."""
    if config.get("testnet"):
        return "https://api.hyperliquid-testnet.xyz"
    return "https://api.hyperliquid.xyz"


def setup_info(config: dict):
    """Create and return an Info client."""
    from hyperliquid.info import Info
    return Info(get_api_url(config), skip_ws=True)


def setup_exchange(config: dict):
    """Create and return an Exchange client."""
    from eth_account import Account
    from hyperliquid.exchange import Exchange
    from hyperliquid.info import Info

    wallet = Account.from_key(config["secret_key"])
    info = Info(get_api_url(config), skip_ws=True)
    exchange = Exchange(
        wallet,
        get_api_url(config),
        account_address=config["account_address"],
        vault_address=config.get("vault_address"),
    )
    return exchange, info


def check_asset_allowed(config: dict, coin: str) -> bool:
    """Check if trading this asset is allowed by config."""
    allowed = config.get("allowed_assets", [])
    if not allowed:  # empty = all allowed
        return True
    return coin.upper() in [a.upper() for a in allowed]


def format_usd(value) -> str:
    """Format a number as USD."""
    try:
        v = float(value)
        if abs(v) >= 1:
            return f"${v:,.2f}"
        return f"${v:.6f}"
    except (ValueError, TypeError):
        return str(value)


def format_pnl(value) -> str:
    """Format PnL with +/- sign."""
    try:
        v = float(value)
        sign = "+" if v >= 0 else ""
        return f"{sign}{format_usd(v)}"
    except (ValueError, TypeError):
        return str(value)


def output_json(data: dict):
    """Print JSON output for the skill to parse."""
    print(json.dumps(data, indent=2, default=str))
