#!/usr/bin/env python3
"""
Hyperliquid Transfer / Fund Commands
Move funds: spot↔perp, send USDC, withdraw.

Usage:
  python3 hl_transfer.py to_spot <AMOUNT>
  python3 hl_transfer.py to_perp <AMOUNT>
  python3 hl_transfer.py send_usd <ADDRESS> <AMOUNT>
  python3 hl_transfer.py withdraw <AMOUNT>
  python3 hl_transfer.py spot_balances

All commands output JSON. Use --preview flag for dry run.
"""

import sys
import json
import traceback

from hl_config import (
    load_config, validate_config, setup_exchange, setup_info,
    format_usd, output_json
)


def cmd_to_spot(exchange, info, config, amount: float, preview: bool = False):
    """Transfer USDC from perp wallet to spot wallet."""
    if preview:
        # Check available balance
        address = config["account_address"]
        state = info.user_state(address)
        margin = state.get("marginSummary", {})
        available = float(margin.get("accountValue", 0)) - float(margin.get("totalMarginUsed", 0))
        output_json({
            "command": "to_spot",
            "preview": True,
            "amount": amount,
            "available_in_perp": round(available, 2),
            "sufficient": available >= amount,
        })
        return

    result = exchange.usd_class_transfer(amount, True)  # True = to spot
    output_json({
        "command": "to_spot",
        "status": result.get("status", "unknown"),
        "amount": amount,
        "direction": "perp → spot",
        "raw_response": result,
    })


def cmd_to_perp(exchange, info, config, amount: float, preview: bool = False):
    """Transfer USDC from spot wallet to perp wallet."""
    if preview:
        address = config["account_address"]
        spot_state = info.spot_user_state(address)
        usdc_balance = 0
        for bal in spot_state.get("balances", []):
            if bal.get("coin", "").upper() in ("USDC", "USDC:USDC"):
                usdc_balance = float(bal.get("total", 0))
                break
        output_json({
            "command": "to_perp",
            "preview": True,
            "amount": amount,
            "available_in_spot": round(usdc_balance, 2),
            "sufficient": usdc_balance >= amount,
        })
        return

    result = exchange.usd_class_transfer(amount, False)  # False = to perp
    output_json({
        "command": "to_perp",
        "status": result.get("status", "unknown"),
        "amount": amount,
        "direction": "spot → perp",
        "raw_response": result,
    })


def cmd_send_usd(exchange, info, config, destination: str, amount: float, preview: bool = False):
    """Send USDC to another Hyperliquid address."""
    if not destination.startswith("0x") or len(destination) != 42:
        output_json({
            "error": "invalid_address",
            "message": f"Invalid address: {destination}. Must be 42-character hex starting with 0x.",
        })
        return

    if preview:
        output_json({
            "command": "send_usd",
            "preview": True,
            "destination": destination,
            "amount": amount,
            "warning": "This will send USDC to the specified address on Hyperliquid L1. Double-check the address.",
        })
        return

    result = exchange.usd_transfer(amount, destination)
    output_json({
        "command": "send_usd",
        "status": result.get("status", "unknown"),
        "destination": destination,
        "amount": amount,
        "raw_response": result,
    })


def cmd_withdraw(exchange, info, config, amount: float, preview: bool = False):
    """Withdraw USDC to Arbitrum (via bridge)."""
    if preview:
        address = config["account_address"]
        state = info.user_state(address)
        withdrawable = float(state.get("withdrawable", 0))
        output_json({
            "command": "withdraw",
            "preview": True,
            "amount": amount,
            "withdrawable": round(withdrawable, 2),
            "sufficient": withdrawable >= amount,
            "fee": "$1",
            "estimated_time": "~5 minutes",
            "destination": "Your Arbitrum wallet",
            "warning": "Withdrawal goes to your connected Arbitrum address. There is a $1 bridge fee.",
        })
        return

    # Note: API wallets typically cannot withdraw. This will fail if using an API wallet.
    # The main wallet private key is needed for withdrawals.
    result = exchange.withdraw(amount)
    output_json({
        "command": "withdraw",
        "status": result.get("status", "unknown"),
        "amount": amount,
        "fee": 1.0,
        "raw_response": result,
    })


def cmd_spot_balances(info, config):
    """Show detailed spot wallet balances."""
    address = config["account_address"]
    spot_state = info.spot_user_state(address)

    balances = []
    for bal in spot_state.get("balances", []):
        total = float(bal.get("total", 0))
        if total > 0:
            balances.append({
                "token": bal.get("coin", "?"),
                "total": total,
                "available": total - float(bal.get("hold", 0)),
                "hold": float(bal.get("hold", 0)),
            })

    output_json({
        "command": "spot_balances",
        "count": len(balances),
        "balances": balances,
    })


def main():
    if len(sys.argv) < 2:
        output_json({"error": "usage", "message": "Usage: hl_transfer.py <command> [args] [--preview]"})
        sys.exit(1)

    config = load_config()
    if not validate_config(config):
        sys.exit(1)

    preview = "--preview" in sys.argv
    args = [a for a in sys.argv if a != "--preview"]
    command = args[1].lower()

    try:
        if command == "spot_balances":
            info = setup_info(config)
            cmd_spot_balances(info, config)
        else:
            exchange, info = setup_exchange(config)

            if command == "to_spot":
                cmd_to_spot(exchange, info, config, float(args[2]), preview)
            elif command == "to_perp":
                cmd_to_perp(exchange, info, config, float(args[2]), preview)
            elif command == "send_usd":
                cmd_send_usd(exchange, info, config, args[2], float(args[3]), preview)
            elif command == "withdraw":
                cmd_withdraw(exchange, info, config, float(args[2]), preview)
            else:
                output_json({"error": "unknown_command", "message": f"Unknown transfer command: {command}"})
                sys.exit(1)

    except IndexError:
        output_json({"error": "missing_args", "message": f"Not enough arguments for '{command}'."})
        sys.exit(1)
    except Exception as e:
        output_json({
            "error": "execution_error",
            "message": str(e),
            "traceback": traceback.format_exc(),
        })
        sys.exit(1)


if __name__ == "__main__":
    main()
