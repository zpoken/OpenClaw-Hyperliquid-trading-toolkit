#!/bin/bash
# ============================================================
# Hyperliquid Trading Skill — Installer for OpenClaw
# ============================================================
# Usage:
#   chmod +x install.sh && ./install.sh
#
# What it does:
#   1. Installs Python dependencies
#   2. Copies skill files to OpenClaw workspace
#   3. Creates config.json if it doesn't exist
#   4. Adds skill to OpenClaw config
# ============================================================

set -e

SKILL_NAME="hyperliquid-trading"
OPENCLAW_DIR="$HOME/.openclaw"
SKILL_DIR="$OPENCLAW_DIR/workspace/skills/$SKILL_NAME"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "🔧 Installing Hyperliquid Trading Skill for OpenClaw"
echo "=================================================="

# Step 1: Install Python dependencies
echo ""
echo "📦 Installing Python dependencies..."
pip install hyperliquid-python-sdk>=0.22.0 eth-account>=0.13.0 2>/dev/null || \
pip install --break-system-packages hyperliquid-python-sdk>=0.22.0 eth-account>=0.13.0 2>/dev/null || \
pip3 install hyperliquid-python-sdk>=0.22.0 eth-account>=0.13.0 2>/dev/null || {
    echo "⚠️  Could not install via pip. Try manually:"
    echo "   pip install hyperliquid-python-sdk eth-account"
}

# Step 2: Create skill directory
echo ""
echo "📂 Setting up skill directory at $SKILL_DIR..."
mkdir -p "$SKILL_DIR/scripts"

# Step 3: Copy files
echo "📋 Copying skill files..."
cp "$SCRIPT_DIR/SKILL.md" "$SKILL_DIR/SKILL.md"
cp "$SCRIPT_DIR/scripts/hl_config.py" "$SKILL_DIR/scripts/hl_config.py"
cp "$SCRIPT_DIR/scripts/hl_info.py" "$SKILL_DIR/scripts/hl_info.py"
cp "$SCRIPT_DIR/scripts/hl_trade.py" "$SKILL_DIR/scripts/hl_trade.py"
cp "$SCRIPT_DIR/scripts/hl_transfer.py" "$SKILL_DIR/scripts/hl_transfer.py"

# Step 4: Create config if not exists
if [ ! -f "$SKILL_DIR/config.json" ]; then
    echo ""
    echo "📝 Creating config.json (you'll need to fill in your keys)..."
    cp "$SCRIPT_DIR/config.example.json" "$SKILL_DIR/config.json"
    echo "   Config created at: $SKILL_DIR/config.json"
    echo ""
    echo "   ⚠️  IMPORTANT: Edit config.json with your wallet details:"
    echo "   nano $SKILL_DIR/config.json"
    echo ""
    echo "   You need:"
    echo "   - account_address: Your main Hyperliquid wallet address"
    echo "   - secret_key: API wallet private key (from https://app.hyperliquid.xyz/API)"
else
    echo "   Config already exists, skipping."
fi

# Step 5: Add to OpenClaw config (if openclaw.json exists)
OPENCLAW_CONFIG="$OPENCLAW_DIR/openclaw.json"
if [ -f "$OPENCLAW_CONFIG" ]; then
    if ! grep -q "$SKILL_NAME" "$OPENCLAW_CONFIG"; then
        echo ""
        echo "📌 Add this to your openclaw.json skills.entries:"
        echo "   \"$SKILL_NAME\": { \"enabled\": true }"
    fi
else
    echo ""
    echo "📌 When OpenClaw is configured, add to skills.entries:"
    echo "   \"$SKILL_NAME\": { \"enabled\": true }"
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "🧪 Test with: cd $SKILL_DIR/scripts && python3 hl_info.py balance"
echo "   (will fail until you configure config.json with real keys)"
echo ""
echo "🚀 After configuring, restart OpenClaw and try:"
echo "   \"Show my Hyperliquid balance\""
echo "   \"Buy 0.1 ETH on HL\""
echo "   \"What are my positions?\""
